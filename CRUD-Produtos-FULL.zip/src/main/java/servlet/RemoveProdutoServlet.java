package servlet;
import banco.Banco;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;
import java.io.*;
@WebServlet("/removeProduto")
public class RemoveProdutoServlet extends HttpServlet{
protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
int id=Integer.parseInt(req.getParameter("id"));
new Banco().removeProduto(id);
res.sendRedirect("listaProdutos");
}}