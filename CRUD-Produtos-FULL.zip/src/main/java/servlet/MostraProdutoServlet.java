package servlet;
import banco.Banco;
import model.Produto;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;
import java.io.*;
@WebServlet("/mostraProduto")
public class MostraProdutoServlet extends HttpServlet{
protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
int id=Integer.parseInt(req.getParameter("id"));
Produto p=new Banco().buscaProduto(id);
req.setAttribute("produto",p);
req.getRequestDispatcher("formAlteraProduto.jsp").forward(req,res);
}}