package servlet;
import banco.Banco;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;
import java.io.*;
@WebServlet("/listaProdutos")
public class ListaProdutoServlet extends HttpServlet{
protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
req.setAttribute("produtos",new Banco().getProdutos());
req.getRequestDispatcher("listaProdutos.jsp").forward(req,res);
}}