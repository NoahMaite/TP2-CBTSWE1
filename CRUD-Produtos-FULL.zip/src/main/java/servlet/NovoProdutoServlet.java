package servlet;
import banco.Banco;
import model.Produto;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;
import java.io.*;
@WebServlet("/novoProduto")
public class NovoProdutoServlet extends HttpServlet{
protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
Produto p=new Produto();
p.setNome(req.getParameter("nome"));
p.setUnidadeCompra(Integer.parseInt(req.getParameter("unidadeCompra")));
p.setDescricao(req.getParameter("descricao"));
p.setQtdPrevistoMes(Double.parseDouble(req.getParameter("qtdPrevistoMes")));
p.setPrecoMaxComprado(Double.parseDouble(req.getParameter("precoMaxComprado")));
new Banco().adiciona(p);
res.sendRedirect("listaProdutos");
}}