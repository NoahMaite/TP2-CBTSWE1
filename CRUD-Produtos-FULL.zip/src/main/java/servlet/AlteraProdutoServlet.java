package servlet;
import banco.Banco;
import model.Produto;
import javax.servlet.*;import javax.servlet.http.*;import javax.servlet.annotation.*;
import java.io.*;
@WebServlet("/alteraProduto")
public class AlteraProdutoServlet extends HttpServlet{
protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
int id=Integer.parseInt(req.getParameter("id"));
Banco b=new Banco();
Produto p=b.buscaProduto(id);
p.setNome(req.getParameter("nome"));
p.setUnidadeCompra(Integer.parseInt(req.getParameter("unidadeCompra")));
p.setDescricao(req.getParameter("descricao"));
p.setQtdPrevistoMes(Double.parseDouble(req.getParameter("qtdPrevistoMes")));
p.setPrecoMaxComprado(Double.parseDouble(req.getParameter("precoMaxComprado")));
res.sendRedirect("listaProdutos");
}}