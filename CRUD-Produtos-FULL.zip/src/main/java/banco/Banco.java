package banco;
import java.util.*;
import model.Produto;
public class Banco {
private static List<Produto> lista=new ArrayList<>();
private static int id=1;
public void adiciona(Produto p){p.setId(id++);lista.add(p);}
public List<Produto> getProdutos(){return lista;}
public void removeProduto(int id){Produto p=buscaProduto(id);lista.remove(p);}
public Produto buscaProduto(int id){for(Produto p:lista){if(p.getId()==id)return p;}return null;}
}