<form action="novoProduto" method="post">
Nome:<input name="nome"><br>
Unidade:<input name="unidadeCompra"><br>
Descricao:<input name="descricao"><br>
Qtd:<input name="qtdPrevistoMes"><br>
Preco:<input name="precoMaxComprado"><br>
<input type="submit">
</form>