<%@page import="model.Produto"%>
<%Produto p=(Produto)request.getAttribute("produto");%>
<form action="alteraProduto" method="post">
<input type="hidden" name="id" value="<%=p.getId()%>">
Nome:<input name="nome" value="<%=p.getNome()%>"><br>
Unidade:<input name="unidadeCompra" value="<%=p.getUnidadeCompra()%>"><br>
Descricao:<input name="descricao" value="<%=p.getDescricao()%>"><br>
Qtd:<input name="qtdPrevistoMes" value="<%=p.getQtdPrevistoMes()%>"><br>
Preco:<input name="precoMaxComprado" value="<%=p.getPrecoMaxComprado()%>"><br>
<input type="submit">
</form>