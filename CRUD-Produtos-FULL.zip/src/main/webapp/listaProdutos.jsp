<%@page import="java.util.*,model.Produto"%>
<%List<Produto> l=(List<Produto>)request.getAttribute("produtos");%>
<ul>
<%for(Produto p:l){%>
<li><%=p.getNome()%>
<a href="mostraProduto?id=<%=p.getId()%>">Editar</a>
<a href="removeProduto?id=<%=p.getId()%>">Excluir</a>
</li>
<%}%>
</ul>
<a href="index.jsp">Voltar</a>