<h1>Sistema de Produtos</h1>
<a href="formNovoProduto.jsp">Cadastrar</a><br>
<a href="listaProdutos">Listar</a><br>
<a href="creditos.jsp">Créditos</a>